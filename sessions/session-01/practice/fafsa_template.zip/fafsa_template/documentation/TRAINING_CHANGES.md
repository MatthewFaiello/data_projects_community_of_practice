# Training copy changes

Version 1.0, 6 November 2026.

- Preserved the supplied CSV and the analysis, plotting, UI and server code.
- Set OPENING_YEAR to 2026 and used it for initial filter choices and selection.
- Set the RStudio Project to skip workspace restoration and session saving.
- Removed inherited Git metadata, local session records, operating-system metadata and deployment records from the practice copy.
- Added an app-only .gitignore aligned with the supplied deployment workflow.
- Replaced the root README with training instructions and retained the original explanation in this folder.

The original uploaded archive remains the source reference. This copy begins without Git history so participants can initialize their own practice repositories.

## Course repository version 2 0
The course repository supplies the slide deck and companion. The separate original app-guide presentation is omitted from this starter; its app screenshot is used in the course deck. The app code and summarized input are unchanged.
